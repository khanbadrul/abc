
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


public class FirstServlet extends HttpServlet {

   
    @Override
    public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException
    {
        //RequestDispatcher rd= req.getRequestDispatcher("SecondServlet");
        //rd.forward(req, res);
        
        String str=req.getParameter("t1");
        
        //HttpSession ses=req.getSession();
        //ses.setAttribute("name", str);
        
        
       // Cookie cookie= new Cookie("name",str);
       // res.addCookie(cookie);
       // res.sendRedirect("SecondServlet");
        
        res.sendRedirect("SecondServlet?name="+str);
    }

}
