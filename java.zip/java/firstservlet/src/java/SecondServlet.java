
import static java.io.FileDescriptor.out;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


public class SecondServlet extends HttpServlet {

   
    public void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException
    { 
       // HttpSession ses = req.getSession();
       // String str = (String) ses.getAttribute("name");
        
       // Cookie cookies[]=req.getCookies();
       // String str=null;
        
       // for(Cookie c: cookies)
       // { 
        //    if(c.getName().equals("name"))
        //    {
        //        str=c.getValue();
        //        
         //   }
            
       // }
        
        String str = req.getParameter("name");
      PrintWriter out= res.getWriter();
      out.println(str);
    }

}