
public class StaticBlock {
    static {
            System.out.println("This is Static 1");
            
    }
     static {
            System.out.println("This is Static 2");
            
    }
      static {
            System.out.println("This is Static 3");
            
    }
       static {
            System.out.println("This is Static 4");
            
    }
       
    public static void main(String[] args) {
        System.out.println("this is main");
    }
   
    
}
