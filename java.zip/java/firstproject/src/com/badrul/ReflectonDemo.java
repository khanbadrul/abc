
package com.badrul;

public class ReflectonDemo {
    
    public static void main(String[] args) throws Exception{
        
        Class c=Class.forName("com.badrul.ReflectionTestNew");
        ReflectionTestNew t = (ReflectionTestNew)c.newInstance();
        t.show();
    }
}

class ReflectionTestNew {

    void show(){
         System.out.println("this is example of reflection");
    }
    
}
