
package com.badrul;


public class ReflectionTest {

    void show(){
         System.out.println("this is example of reflection");
    }
    
}
