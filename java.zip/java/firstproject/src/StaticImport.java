

public class StaticImport {
    static {
            System.out.println("this is static without main");
    }
}
