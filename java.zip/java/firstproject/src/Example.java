public class Example {
   public static void main(String args[]){
      Object A = new Long( 7 );
      Long  L = new Long( 7 ) ;
      if( A.equals( L ))
          System.out.println("Equal");
      else System.out.println("Not Equal");
    }
  }